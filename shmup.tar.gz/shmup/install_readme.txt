To install:
 download the shmup.tar.gz, music.tar.gz, and sounds.tar.gz
 Extract all files
 Place the sounds and music folders in the shmup folder
 Open a shell in the shmup folder and type ./install.sh
 
 enjoy
