game_path=~/.local/share/games

if [ -d $game_path ]; then
	echo "Games directory exist. moving on...."
else
	echo "Games directory does not exist. Creating ${game_path}"
	mkdir $game_path
fi

if [ -d $game_path/shmup ]; then
	:
else
	echo "Creating directory ${game_path}/shmup"
	mkdir $game_path/shmup
fi

# Get all folders and files and copy to folder
files=*
for file in $files; do
	if [ $file != "install.sh" ]; then
		echo "Copying ${file} to ${game_path}/shmup/${file}"
		cp -r $file $game_path/shmup/
	fi
done

echo "Creating Shortcuts"
cp $game_path/shmup/shmup.desktop ~/.local/share/applications/shmup.desktop
ln -s ~/.local/share/applications/shmup.desktop ~/Desktop/shmup.desktop
gio set ~/Desktop/shmup.desktop "metadata::trusted" true

